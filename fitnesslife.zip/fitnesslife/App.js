import * as React from 'react';
import { Button, View, Text, TextInput, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { createStackNavigator } from '@react-navigation/stack';

function LoginScreen({ navigation }) {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#6200EE' }}>
      <Text
        style={{
          fontSize: 40,
          fontWeight: 'bold',
          textAlign: 'center',
          color: '#fff',
          marginTop: 22,
        }}>
        FitnessLife
      </Text>

      <View
        style={{
          justifyContent: 'space-around',
          alignItems: 'center',
          marginTop: 61,
        }}>
        <View
          style={{
            width: 320,
            backgroundColor: '#fff',
            height: 490,
            borderRadius: 10,
            padding: 19,
          }}>
          <Text
            style={{ fontSize: 25, fontWeight: 'bold', textAlign: 'center' }}>
            Login Here
          </Text>

          <Text style={{ fontSize: 15, marginTop: 22 }}>Email</Text>
          <TextInput
            placeholder="Enter Email Address"
            style={{
              borderWidth: 1,
              paddingLeft: 10,
              padding: 3,
              marginTop: 10,
              borderRadius: 4,
            }}
          />

          <Text style={{ fontSize: 15, marginTop: 22 }}>Password</Text>
          <TextInput
            placeholder="Enter Password"
            style={{
              borderWidth: 1,
              paddingLeft: 10,
              padding: 3,
              marginTop: 10,
              borderRadius: 4,
            }}
          />

          <Text
            style={{
              backgroundColor: '#000',
              color: '#fff',
              fontWeight: 'bold',
              marginTop: 22,
              textAlign: 'center',
              borderRadius: 8,
              padding: 8,
            }}>
            Login
          </Text>

          <Text
            style={{
              backgroundColor: '#000',
              color: '#fff',
              fontWeight: 'bold',
              marginTop: 22,
              textAlign: 'center',
              borderRadius: 8,
              padding: 8,
            }}>
            SignUp with Google
          </Text>

          <Text
            style={{
              backgroundColor: '#000',
              color: '#fff',
              fontWeight: 'bold',
              marginTop: 22,
              textAlign: 'center',
              borderRadius: 8,
              padding: 8,
            }}>
            SignUp with Facebook
          </Text>

          <TouchableOpacity onPress={() => navigation.navigate('homescreen')}>
            <Text
              style={{
                marginTop: 32,
                textAlign: 'center',
                fontWeight: 'bold',
                fontSize: 18,
              }}>
              SkipNow
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

function HomeScreen({ navigation }) {
  return (
    <SafeAreaView style={{ backgroundColor: '#6200EE', flex: 1 }}>
      <View style={{ backgroundColor: '#fff', color: '#000' }}>
        <Text
          style={{
            fontWeight: 'bold',
            fontSize: 32,
            padding: 22,
            textAlign: 'center',
          }}>
          FitnessLife
        </Text>
      </View>

      <View style={{ alignItems: 'center' }}>
        <View
          style={{
            backgroundColor: '#1A2A52',
            padding: 20,
            width: 350,
            marginTop: 15,
            borderRadius: 12,
            flexDirection: 'column',
          }}>
          <View
            style={{ backgroundColor: '#fff', padding: 10, borderRadius: 13 }}>
            <View
              style={{
                justifyContent: 'space-around',
                alignItems: 'center',
                flexDirection: 'row',
              }}>
              <View
                style={{
                  width: 100,
                  height: 120,
                  padding: 8,
                  borderRightWidth: 1,
                  borderColor: '#000',
                  flexDirection: 'column',
                  justifyContent: 'space-around',
                  alignItems: 'center',
                }}>
                <Text
                  style={{ color: 'red', fontSize: 20, fontWeight: 'bold' }}>
                  Move
                </Text>
                <Text style={{ color: 'red', fontSize: 10 }}>-</Text>
                <Text style={{ color: 'red', fontSize: 12 }}>78%</Text>
                <Text style={{ color: 'red', fontSize: 14 }}>530Kcals</Text>
              </View>

              <View
                style={{
                  width: 100,
                  height: 120,
                  padding: 8,
                  borderRightWidth: 1,
                  borderColor: '#000',
                  flexDirection: 'column',
                  justifyContent: 'space-around',
                  alignItems: 'center',
                }}>
                <Text
                  style={{ color: 'green', fontSize: 20, fontWeight: 'bold' }}>
                  Exercise
                </Text>
                <Text style={{ color: 'green', fontSize: 10 }}>-</Text>
                <Text style={{ color: 'green', fontSize: 12 }}>89%</Text>
                <Text style={{ color: 'green', fontSize: 14 }}>38 Min</Text>
              </View>

              <View
                style={{
                  width: 100,
                  height: 120,
                  padding: 8,
                  borderColor: '#000',
                  flexDirection: 'column',
                  justifyContent: 'space-around',
                  alignItems: 'center',
                }}>
                <Text
                  style={{ color: 'blue', fontSize: 20, fontWeight: 'bold' }}>
                  Walk
                </Text>
                <Text style={{ color: 'blue', fontSize: 10 }}>-</Text>
                <Text style={{ color: 'blue', fontSize: 12 }}>100%</Text>
                <Text style={{ color: 'blue', fontSize: 14 }}>3,5 KM</Text>
              </View>
            </View>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginTop: 14,
              }}>
              <Text style={{ fontSize: 12, color: '#000', fontWeight: 'bold' }}>
                Status:
                <Text
                  style={{ fontSize: 12, color: 'green', fontWeight: 'bold' }}>
                  Good
                </Text>
              </Text>
              <Text style={{ fontSize: 12, color: '#000', fontWeight: 'bold' }}>
                Date: Mar 20 2022
              </Text>
            </View>
          </View>

          <View
            style={{
              backgroundColor: '#fff',
              padding: 10,
              borderRadius: 13,
              marginTop: 22,
            }}>
            <View
              style={{
                justifyContent: 'space-around',
                alignItems: 'center',
                flexDirection: 'row',
              }}>
              <View
                style={{
                  width: 100,
                  height: 120,
                  padding: 8,
                  borderRightWidth: 1,
                  borderColor: '#000',
                  flexDirection: 'column',
                  justifyContent: 'space-around',
                  alignItems: 'center',
                }}>
                <Text
                  style={{ color: 'red', fontSize: 20, fontWeight: 'bold' }}>
                  Move
                </Text>
                <Text style={{ color: 'red', fontSize: 10 }}>-</Text>
                <Text style={{ color: 'red', fontSize: 12 }}>66%</Text>
                <Text style={{ color: 'red', fontSize: 14 }}>300Kcals</Text>
              </View>

              <View
                style={{
                  width: 100,
                  height: 120,
                  padding: 8,
                  borderRightWidth: 1,
                  borderColor: '#000',
                  flexDirection: 'column',
                  justifyContent: 'space-around',
                  alignItems: 'center',
                }}>
                <Text
                  style={{ color: 'green', fontSize: 20, fontWeight: 'bold' }}>
                  Exercise
                </Text>
                <Text style={{ color: 'green', fontSize: 10 }}>-</Text>
                <Text style={{ color: 'green', fontSize: 12 }}>59%</Text>
                <Text style={{ color: 'green', fontSize: 14 }}>18 Min</Text>
              </View>

              <View
                style={{
                  width: 100,
                  height: 120,
                  padding: 8,
                  borderColor: '#000',
                  flexDirection: 'column',
                  justifyContent: 'space-around',
                  alignItems: 'center',
                }}>
                <Text
                  style={{ color: 'blue', fontSize: 20, fontWeight: 'bold' }}>
                  Walk
                </Text>
                <Text style={{ color: 'blue', fontSize: 10 }}>-</Text>
                <Text style={{ color: 'blue', fontSize: 12 }}>50%</Text>
                <Text style={{ color: 'blue', fontSize: 14 }}>1,2 KM</Text>
              </View>
            </View>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginTop: 14,
              }}>
              <Text style={{ fontSize: 12, color: '#000', fontWeight: 'bold' }}>
                Status:
                <Text
                  style={{ fontSize: 12, color: 'red', fontWeight: 'bold' }}>
                  Bad
                </Text>
              </Text>
              <Text style={{ fontSize: 12, color: '#000', fontWeight: 'bold' }}>
                Date: Mar 20 2022
              </Text>
            </View>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const Stack = createStackNavigator();

function MyStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="loginscreen" component={LoginScreen} />
      <Stack.Screen name="homescreen" component={HomeScreen} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <MyStack />
    </NavigationContainer>
  );
}
